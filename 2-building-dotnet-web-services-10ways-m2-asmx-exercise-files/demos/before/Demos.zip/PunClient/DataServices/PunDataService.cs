﻿using System;
using System.Collections.Generic;
using System.Linq;
using PunClient.Transports;

namespace PunClient.DataServices
{
    class PunDataService
    {
        public PunDataService()
        {
        }

        public Pun[] GetPuns()
        {
            throw new NotImplementedException();
        }

        public Pun GetPunByID(int punID)
        {
            throw new NotImplementedException();
        }

        public void CreatePun(Pun pun)
        {
            throw new NotImplementedException();
        }

        public void UpdatePun(Pun pun)
        {
            throw new NotImplementedException();
        }

        public void DeletePun(int punID)
        {
            throw new NotImplementedException();
        }
    }
}
